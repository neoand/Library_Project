# -*- coding: utf-8 -*-
# library_app/models/stage.py

from odoo import models, fields, api
from odoo.exceptions import ValidationError, UserError


class BookStage(models.Model):
    _name = 'library.book.stage'
    _description = 'Book Stage'
    _order = 'sequence, name'
    _rec_name = 'name'

    # Campos básicos
    name = fields.Char(
        string='Name',
        required=True,
        translate=True,
        help="Name of the book stage (e.g., Draft, Available, Borrowed)"
    )

    description = fields.Text(
        string='Description',
        translate=True,
        help="Detailed description of what this stage represents"
    )

    sequence = fields.Integer(
        string='Sequence',
        default=10,
        help="Determines the order of stages in the workflow"
    )

    fold = fields.Boolean(
        string='Folded in Kanban',
        default=False,
        help="If checked, this stage will be folded (collapsed) by default in the Kanban view"
    )

    is_default = fields.Boolean(
        string='Default Stage',
        default=False,
        help="If checked, this stage will be assigned to new books by default"
    )

    # Campos de aparência
    color = fields.Integer(
        string='Color Index',
        default=0,
        help="Color used to visually distinguish this stage in Kanban view"
    )

    # Relacionamentos
    book_ids = fields.One2many(
        comodel_name='library.book',
        inverse_name='stage_id',
        string='Books in this Stage'
    )

    book_count = fields.Integer(
        string='Book Count',
        compute='_compute_book_count',
        store=True,
        help="Number of books currently in this stage"
    )

    # Campos de sistema
    active = fields.Boolean(
        string='Active',
        default=True,
        help="If unchecked, this stage will be hidden and cannot be selected"
    )

    # Métodos computados
    @api.depends('book_ids')
    def _compute_book_count(self):
        """Calcula o número de livros neste estágio"""
        for stage in self:
            stage.book_count = len(stage.book_ids)

    # Restrições e validações
    @api.constrains('is_default')
    def _check_default_stage(self):
        """Garante que apenas um estágio seja marcado como padrão"""
        default_stages = self.search([('is_default', '=', True)])
        if len(default_stages) > 1:
            raise ValidationError("Only one stage can be set as default.")

    @api.constrains('sequence')
    def _check_sequence_positive(self):
        """Garante que a sequência seja um número positivo"""
        for stage in self:
            if stage.sequence < 0:
                raise ValidationError("Sequence must be a positive number.")

    @api.constrains('name')
    def _check_name_unique(self):
        """Garante que os nomes dos estágios sejam únicos"""
        for stage in self:
            if self.search_count([
                ('name', '=', stage.name),
                ('id', '!=', stage.id)
            ]) > 0:
                raise ValidationError("Stage name must be unique.")

    # Métodos de ação
    def action_set_default(self):
        """Define este estágio como o padrão"""
        self.ensure_one()
        # Remover o padrão de todos os outros estágios
        self.search([('is_default', '=', True)]).write({'is_default': False})
        self.write({'is_default': True})
        return True

    def action_view_books(self):
        """Abre a vista de livros neste estágio"""
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': f'Books in {self.name}',
            'res_model': 'library.book',
            'view_mode': 'tree,form,kanban',
            'domain': [('stage_id', '=', self.id)],
            'context': {'default_stage_id': self.id}
        }

    # Sobrescrevendo métodos padrão
    @api.model
    def create(self, vals):
        """Sobrescreve o método create para garantir apenas um estágio padrão"""
        if vals.get('is_default'):
            # Remover o padrão de todos os outros estágios
            self.search([('is_default', '=', True)]).write({'is_default': False})
        return super().create(vals)

    def write(self, vals):
        """Sobrescreve o método write para garantir apenas um estágio padrão"""
        if vals.get('is_default'):
            # Remover o padrão de todos os outros estágios
            self.search([('is_default', '=', True)]).write({'is_default': False})
        return super().write(vals)

    def unlink(self):
        """Impede a exclusão de estágios que possuem livros ou são padrão"""
        for stage in self:
            if stage.book_count > 0:
                raise UserError(
                    f"Cannot delete stage '{stage.name}' because it has {stage.book_count} "
                    f"book(s) assigned. Please reassign the books first."
                )
            if stage.is_default:
                raise UserError(
                    f"Cannot delete stage '{stage.name}' because it is the default stage. "
                    f"Please set another stage as default first."
                )
        return super().unlink()

    # Métodos auxiliares
    @api.model
    def get_default_stage(self):
        """Retorna o estágio padrão (para uso em valores padrão)"""
        return self.search([('is_default', '=', True)], limit=1)