# -*- coding: utf-8 -*-
# library_app/models/book.py

from odoo import models, fields, api
from odoo.exceptions import ValidationError
from datetime import date


class LibraryBook(models.Model):
    _name = 'library.book'
    _description = 'Library Book'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'name, date_published desc'

    # --- Campos Principais ---
    name = fields.Char(
        string='Title',
        required=True,
        tracking=True,
        help="Title of the book"
    )

    author_id = fields.Many2one(
        comodel_name='res.partner',
        string='Author',
        tracking=True,
        domain="[('is_author', '=', True)]",
        help="Author of the book"
    )

    user_id = fields.Many2one(
        comodel_name='res.users',
        string='Responsible',
        tracking=True,
        default=lambda self: self.env.user,
        help="Person responsible for this book"
    )

    stage_id = fields.Many2one(
        comodel_name='library.book.stage',
        string='Stage',
        group_expand='_read_group_stage_ids',
        tracking=True,
        copy=False,
        default=lambda self: self._default_stage_id(),
        domain="[('fold', '=', False)]",
        help="Current stage in the book's lifecycle"
    )

    category_ids = fields.Many2many(
        comodel_name='library.book.category',
        relation='library_book_category_rel',
        column1='book_id',
        column2='category_id',
        string='Categories',
        help="Categories this book belongs to"
    )

    date_published = fields.Date(
        string='Published Date',
        tracking=True,
        help="Date when the book was first published"
    )

    cover = fields.Binary(
        string='Book Cover',
        attachment=True,
        help="Cover image of the book"
    )

    isbn = fields.Char(
        string='ISBN',
        size=13,
        tracking=True,
        help="International Standard Book Number"
    )

    # --- Campos Computados ---
    category_names = fields.Char(
        string="Category Names",
        compute='_compute_category_names',
        store=False,
        help="Comma-separated list of category names"
    )

    age_years = fields.Integer(
        string='Age (Years)',
        compute='_compute_age',
        store=True,
        help="Age of the book in years since publication"
    )

    is_published = fields.Boolean(
        string='Is Published',
        compute='_compute_is_published',
        store=True,
        help="True if the book has been published"
    )

    # --- Restrições e Validações ---
    _sql_constraints = [
        ('isbn_unique', 'UNIQUE(isbn)', 'ISBN must be unique.'),
        ('name_author_unique', 'UNIQUE(name, author_id)', 'Book title must be unique per author.'),
    ]

    # --- Métodos de Apoio ---

    @api.model
    def _default_stage_id(self):
        """Retorna o estágio padrão (primeiro na sequência)"""
        return self.env['library.book.stage'].search([], order='sequence', limit=1)

    @api.depends('date_published')
    def _compute_age(self):
        """Calcula a idade do livro em anos"""
        today = date.today()
        for book in self:
            if book.date_published:
                delta = today - book.date_published
                book.age_years = delta.days // 365
            else:
                book.age_years = 0

    @api.depends('date_published')
    def _compute_is_published(self):
        """Determina se o livro foi publicado"""
        for book in self:
            book.is_published = bool(book.date_published and book.date_published <= date.today())

    @api.depends('category_ids.name')
    def _compute_category_names(self):
        """Concatena os nomes das categorias para exibição"""
        for book in self:
            book.category_names = ", ".join(book.category_ids.mapped('name')) or 'Uncategorized'

    @api.model
    def _read_group_stage_ids(self, stages, domain, order):
        """Necessário para a funcionalidade 'group_expand' do Kanban"""
        return stages.search([], order=order)

    # --- Métodos de CRUD ---

    @api.model_create_multi
    def create(self, vals_list):
        """Override do método create para garantir consistência"""
        for vals in vals_list:
            # Garantir que temos um estágio padrão
            if not vals.get('stage_id'):
                vals['stage_id'] = self._default_stage_id().id

            # Promover contato a autor se necessário
            if vals.get('author_id'):
                author = self.env['res.partner'].browse(vals['author_id'])
                if not author.is_author:
                    author.write({'is_author': True})

        books = super().create(vals_list)

        # Registrar mensagem de atividade
        books._message_log_batch(bodies={
            book.id:
                f"Book '{book.name}' created with stage '{book.stage_id.name}'"
            for book in books
        })

        return books

    def write(self, vals):
        """Override do método write para garantir consistência"""
        # Promover contato a autor se um novo autor for definido
        if 'author_id' in vals and vals['author_id']:
            new_author = self.env['res.partner'].browse(vals['author_id'])
            if not new_author.is_author:
                new_author.write({'is_author': True})

        result = super().write(vals)

        # Registrar mudanças importantes
        if 'stage_id' in vals:
            self._message_log_batch(bodies={
                book.id: f"Book stage changed to '{book.stage_id.name}'"
                for book in self
            })

        return result

    # --- Restrições e Validações ---

    @api.constrains('isbn')
    def _check_isbn_format(self):
        """Valida o formato do ISBN (versão simples)"""
        for book in self:
            if book.isbn and len(book.isbn) not in (10, 13):
                raise ValidationError("ISBN must be 10 or 13 characters long.")

    @api.constrains('date_published')
    def _check_date_published(self):
        """Garante que a data de publicação não é futura"""
        for book in self:
            if book.date_published and book.date_published > date.today():
                raise ValidationError("Publication date cannot be in the future.")

    # --- Métodos de Ação ---

    def action_mark_available(self):
        """Marca o livro como disponível"""
        available_stage = self.env['library.book.stage'].search(
            [('name', 'ilike', 'available')],
            limit=1
        )
        if available_stage:
            self.write({'stage_id': available_stage.id})

    def action_mark_borrowed(self):
        """Marca o livro como emprestado"""
        borrowed_stage = self.env['library.book.stage'].search(
            [('name', 'ilike', 'borrowed')],
            limit=1
        )
        if borrowed_stage:
            self.write({'stage_id': borrowed_stage.id})

    def action_open_author(self):
        """Abre a visualização do autor"""
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Author',
            'res_model': 'res.partner',
            'res_id': self.author_id.id,
            'view_mode': 'form',
            'target': 'current',
        }