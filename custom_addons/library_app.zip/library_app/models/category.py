# -*- coding: utf-8 -*-
# library_app/models/category.py

from odoo import models, fields, api
from odoo.exceptions import ValidationError


class BookCategory(models.Model):
    _name = 'library.book.category'
    _description = 'Book Category'
    _order = 'name'
    _parent_name = 'parent_id'
    _parent_store = True
    _rec_name = 'complete_name'

    # Campos básicos
    name = fields.Char(
        string='Category Name',
        required=True,
        translate=True,
        help="Name of the book category"
    )

    complete_name = fields.Char(
        string='Complete Name',
        compute='_compute_complete_name',
        store=True,
        recursive=True
    )

    # Hierarquia de categorias
    parent_id = fields.Many2one(
        comodel_name='library.book.category',
        string='Parent Category',
        index=True,
        ondelete='cascade',
        help="Parent category for hierarchical organization"
    )

    parent_path = fields.Char(index=True)

    child_ids = fields.One2many(
        comodel_name='library.book.category',
        inverse_name='parent_id',
        string='Child Categories'
    )

    # Campos de aparência e organização
    color = fields.Integer(
        string='Color Index',
        help="Color used to visually distinguish categories"
    )

    sequence = fields.Integer(
        string='Sequence',
        default=10,
        help="Determines the display order of categories"
    )

    # Relacionamentos e contadores
    book_ids = fields.Many2many(
        comodel_name='library.book',
        relation='library_book_category_rel',
        column1='category_id',
        column2='book_id',
        string='Books in this Category'
    )

    book_count = fields.Integer(
        string='Book Count',
        compute='_compute_book_count',
        store=True,
        help="Number of books in this category"
    )

    all_book_count = fields.Integer(
        string='Total Books (Including Subcategories)',
        compute='_compute_all_book_count',
        store=False,
        help="Total number of books in this category and all its subcategories"
    )

    # Campos de sistema
    active = fields.Boolean(
        string='Active',
        default=True,
        help="If unchecked, this category will be hidden"
    )

    # Métodos computados
    @api.depends('name', 'parent_id.complete_name')
    def _compute_complete_name(self):
        """Calcula o nome completo com o caminho hierárquico"""
        for category in self:
            if category.parent_id:
                category.complete_name = '%s / %s' % (category.parent_id.complete_name, category.name)
            else:
                category.complete_name = category.name

    @api.depends('book_ids')
    def _compute_book_count(self):
        """Calcula o número de livros diretamente nesta categoria"""
        for category in self:
            category.book_count = len(category.book_ids)

    def _compute_all_book_count(self):
        """Calcula o número total de livros nesta categoria e todas as subcategorias"""
        for category in self:
            # Buscar todas as subcategorias (incluindo a própria)
            all_categories = self.search([('id', 'child_of', category.id)])

            # Contar livros em todas essas categorias
            category.all_book_count = len(all_categories.mapped('book_ids'))

    # Restrições e validações
    @api.constrains('parent_id')
    def _check_parent_id(self):
        """Impede referências circulares na hierarquia de categorias"""
        if not self._check_recursion():
            raise ValidationError("You cannot create recursive categories.")

    @api.constrains('name')
    def _check_name_unique(self):
        """Garante que os nomes das categorias sejam únicos no mesmo nível"""
        for category in self:
            if self.search_count([
                ('name', '=', category.name),
                ('parent_id', '=', category.parent_id.id),
                ('id', '!=', category.id)
            ]) > 0:
                raise ValidationError("Category name must be unique within the same parent category.")

    # Métodos de ação
    def action_view_books(self):
        """Abre a vista de livros nesta categoria"""
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': f'Books in {self.name}',
            'res_model': 'library.book',
            'view_mode': 'tree,form,kanban',
            'domain': [('category_ids', 'in', self.ids)],
            'context': {'default_category_ids': [(6, 0, self.ids)]}
        }

    def action_view_all_books(self):
        """Abre a vista de livros nesta categoria e todas as subcategorias"""
        self.ensure_one()
        all_categories = self.search([('id', 'child_of', self.id)])
        return {
            'type': 'ir.actions.act_window',
            'name': f'Books in {self.name} and subcategories',
            'res_model': 'library.book',
            'view_mode': 'tree,form,kanban',
            'domain': [('category_ids', 'in', all_categories.ids)],
            'context': {'default_category_ids': [(6, 0, all_categories.ids)]}
        }

    # Sobrescrevendo métodos padrão
    def copy(self, default=None):
        """Sobrescreve o método de cópia para evitar copiar relacionamentos"""
        default = default or {}
        default.update({
            'book_ids': False,
            'child_ids': False,
            'book_count': 0
        })
        return super().copy(default)

    def name_get(self):
        """Sobrescreve name_get para retornar o nome completo"""
        return [(category.id, category.complete_name) for category in self]