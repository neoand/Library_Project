{
    'name': "Library App",
    'summary': "Manage library catalog and book lending system",
    'description': """
        Comprehensive library management system for Odoo 18.
        Features include book catalog, author management, categories, 
        workflow stages, and integrated messaging.
    """,
    'author': "Anderson Oliveira & Mentor",
    'website': "https://www.linkedin.com/in/anderson-oliveira-dev/",
    'category': 'Services/Library',
    'version': '18.0.1.0',
    'license': 'LGPL-3',
    'depends': ['base', 'contacts', 'mail', 'web'],
    'data': [
        'security/security.xml',
        'data/library_book_stage_data.xml',
        'views/book_view.xml',
        'views/book_search.xml',
        'views/book_kanban.xml',
        'views/author_view.xml',
        'views/author_search_view.xml',
        'views/category_view.xml',
        'views/stage_view.xml'
    ],
    'demo': [],
    'installable': True,
    'application': True,
    'auto_install': False,
    'icon': '/library_app/static/description/icon.png'
}