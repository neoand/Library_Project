# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import ValidationError

class LibraryBookLoan(models.Model):
    _name = 'library.book.loan'
    _description = 'Book Loan'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'loan_date desc'

    book_id = fields.Many2one(
        comodel_name='library.book',
        string='Book',
        ondelete='cascade',
        index=True,
        required=True,
        tracking=True,
    )
    partner_id = fields.Many2one(
        comodel_name='res.partner',
        string='Borrower',
        domain=[('is_company', '=', False)],  # Apenas pessoas físicas
        ondelete='restrict',  # Impede deletar contatos com empréstimos
        required=True,  # Campo obrigatório
        tracking=True,
        help="Select the person who is borrowing this book"
    )
    loan_date = fields.Date(
        string='Loan Date',
        default=fields.Date.context_today,
        required=True,
        tracking=True,
    )
    return_date = fields.Date(string='Return Date', tracking=True)
    expected_return_date = fields.Date(string='Expected Return Date', tracking=True)
    state = fields.Selection([
        ('ongoing', 'Ongoing'),
        ('done', 'Returned'),
        ('lost', 'Lost'),
    ], string='Status', default='ongoing', tracking=True)

    @api.constrains('partner_id')
    def _check_borrower(self):
        """Valida que o mutuário foi selecionado."""
        for loan in self:
            if not loan.partner_id:
                raise ValidationError("A borrower must be selected for the loan.")

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get('return_date'):
                vals['state'] = 'ongoing'
        return super().create(vals_list)
        return super().create(vals_list)