# -*- coding: utf-8 -*-
# Arquivo vazio ou pode conter imports se necessário